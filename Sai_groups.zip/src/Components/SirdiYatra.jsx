// import React from 'react'
// import { Container } from 'react-bootstrap'

// export const SirdiYatra = () => {
//   return (
//     <div>
        
//         <Container>
// <div style={{backgroundImage:'url("./img/saiyatra-bg-img.svg")', backgroundPosition:''}}>

// </div>


//         </Container>

//     </div>
//   )
// }
