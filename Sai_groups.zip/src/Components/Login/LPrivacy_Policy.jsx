import React from 'react'

const LPrivacy_Policy = () => {
  return (
    <div>
      <div className="text-center mt-3">
        <h3>PRIVACY AND POLICY</h3>
      </div>

      <div className="terms-tagline text-center p-4">
        <p>
          {" "}
          A terms of service agreement typically contains sections pertaining to
          the following description:
        </p>

        <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Velit fuga
          enim eos ipsum nulla dolorum labore exercitationem minus corporis quos
          facere neque quia qui, sit cum eum at veniam quidem.
        </p>
        <p>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Deserunt
          modi consequatur adipisci voluptates, voluptas fugiat, sed, sunt ipsa
          pariatur recusandae quia dolorem! Velit quos minima numquam blanditiis
          quia quas ut?
        </p>
        <p>
          {" "}
          A terms of service agreement typically contains sections pertaining to
          the following description:
        </p>

        <p>
          Lorem ipsum, dolor sit amet consectetur adipisicing elit. Velit fuga
          enim eos ipsum nulla dolorum labore exercitationem minus corporis quos
          facere neque quia qui, sit cum eum at veniam quidem.
        </p>
        <p>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Deserunt
          modi consequatur adipisci voluptates, voluptas fugiat, sed, sunt ipsa
          pariatur recusandae quia dolorem! Velit quos minima numquam blanditiis
          quia quas ut?
        </p>
      </div>
    </div>
  )
}

export default LPrivacy_Policy